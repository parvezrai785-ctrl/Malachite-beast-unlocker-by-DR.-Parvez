#!/system/bin/sh
MODDIR=${0%/*}
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=busybox
URL=http://127.0.0.1:8765/

# Ensure the localhost UI exists. This action never changes performance settings.
if ! "$BB" wget -q -O /dev/null "$URL" 2>/dev/null; then
  if "$BB" httpd --help >/dev/null 2>&1; then
    "$BB" httpd -f -p 127.0.0.1:8765 -h "$MODDIR/web" >/dev/null 2>&1 &
    sleep 1
  fi
fi
am start -a android.intent.action.VIEW -d "$URL" >/dev/null 2>&1
printf '%s\n' 'Malachite Beast v1.8.1' 'Magisk-native WebUI • fixed profile toggles • boot-safe'
