#!/system/bin/sh
MODDIR=${0%/*}
LOG="$MODDIR/logs/service.log"
PIDFILE="$MODDIR/webui.pid"
mkdir -p "$MODDIR/logs"

# BOOT-SAFE: this service ONLY starts the local WebUI. It never changes CPU/GPU/display settings.
sleep 8
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=busybox

if ! "$BB" httpd --help >/dev/null 2>&1; then
  echo "ERROR: BusyBox httpd unavailable; no performance changes applied" >>"$LOG"
  exit 0
fi

# Remove stale pidfile. Do not kill an unrelated process.
if [ -f "$PIDFILE" ]; then
  PID=$(cat "$PIDFILE" 2>/dev/null)
  if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
    # Existing server is enough; do not spawn another one.
    exit 0
  fi
  rm -f "$PIDFILE"
fi

"$BB" httpd -f -p 127.0.0.1:8765 -h "$MODDIR/web" >>"$LOG" 2>&1 &
echo $! > "$PIDFILE"
log(){ echo "$(date '+%F %T') $*" >> "$LOG"; }
log "WebUI started pid=$(cat "$PIDFILE")"
