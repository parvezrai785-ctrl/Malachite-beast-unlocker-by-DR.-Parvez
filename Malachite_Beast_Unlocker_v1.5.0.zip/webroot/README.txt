Malachite Beast WebUI v1.5.0. Requires a WebUI host exposing ksu.exec() or kernelsu.exec().
