# Malachite Beast Unlocker v1.5.0

Developer: DR.Parvez Dev
Target: Redmi Note 14 Pro 5G / Malachite

## Profiles
- Battery: 60 Hz + conservative CPU limits
- Balanced / Default: restores the saved phone refresh settings + moderate CPU limits
- Gaming: restores the saved phone refresh settings + performance CPU profile
- Esport 90: 90 Hz + performance CPU profile
- Esport 120: 120 Hz + performance CPU profile

## v1.5.0
- Clean rebuild from the v1.1.0 backend.
- Balanced is the boot/default profile.
- Balanced no longer forces 90 Hz.
- Gaming is a real standalone profile.
- Gaming no longer forces 90 Hz.
- Esport 90 and Esport 120 retain explicit refresh-rate control.
- Per-app profiles support all five profiles.
- Auto switching falls back to Balanced for unassigned apps.
- Modern responsive gaming WebUI with animated mode transitions.
- Mode-specific visual themes.
- Dynamic Android/kernel/device information.
- In-page Add App selector; no browser prompt().
- 70%-width WebUI controls.
- Installation information is shown during Magisk installation.
- Thermal protection is not disabled.
- GPU/touch sysfs nodes are not force-written.

## WebUI
The WebUI requires a host exposing ksu.exec() or kernelsu.exec().
