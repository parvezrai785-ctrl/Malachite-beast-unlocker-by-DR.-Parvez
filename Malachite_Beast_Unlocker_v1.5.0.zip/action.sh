#!/system/bin/sh
MODDIR=${0%/*}
echo "Malachite Beast Unlocker v1.5.0"
echo "Developer: DR.Parvez Dev"
echo "Default: Balanced (phone refresh rate preserved)"
echo
"$MODDIR/bin/beastctl" status
