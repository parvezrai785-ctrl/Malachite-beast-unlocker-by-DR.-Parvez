#!/system/bin/sh
MODDIR=${0%/*}
STATE=/data/adb/malachite_beast_unlocker
mkdir -p "$STATE/apps"

# Balanced is the default profile. Restore the saved phone defaults first,
# then apply Balanced CPU controls without forcing a refresh rate.
sleep 10
"$MODDIR/bin/beastctl" restore >/dev/null 2>&1
"$MODDIR/bin/beastctl" apply balanced >/dev/null 2>&1
LAST="balanced"

while sleep 1; do
    [ -f "$STATE/auto_enable" ] || continue

    top="$(dumpsys activity activities 2>/dev/null |
        grep -m1 -E 'mResumedActivity' |
        sed -n 's/.* \([A-Za-z0-9._-]*\)\/[^ ]*.*/\1/p')"

    [ -n "$top" ] || continue

    mode="$(cat "$STATE/apps/$top" 2>/dev/null)"
    [ -n "$mode" ] || mode=balanced

    [ "$mode" = "$LAST" ] && continue

    "$MODDIR/bin/beastctl" apply "$mode" >/dev/null 2>&1
    LAST="$mode"
done
